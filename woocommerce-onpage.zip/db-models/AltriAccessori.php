<?php
namespace Op; 
class AltriAccessori extends \OpLib\Term {
  public static function boot() {
    parent::boot();
    self::addGlobalScope('op', function($q) {
      $q->where('op_res', 735)->loaded();
    });
  }
  function accessori() {
    return $this->belongsToMany(Accessori2::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_accessori');
  }
}
