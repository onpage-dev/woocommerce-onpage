<?php
namespace Op; 
class Accessori2 extends \OpLib\Term {
  public static function boot() {
    parent::boot();
    self::addGlobalScope('op', function($q) {
      $q->where('op_res', 1019)->loaded();
    });
  }
  function versione_teglie() {
    return $this->belongsToMany(VersioneTeglie::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_versione_teglie');
  }
  function accessori_decktop() {
    return $this->belongsToMany(AccessoriDecktop::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_accessori_decktop');
  }
  function accessori_lievitatori() {
    return $this->belongsToMany(AccessoriLievitatori::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_accessori_lievitatori');
  }
  function accessori_stand_e_ruote() {
    return $this->belongsToMany(AccessoriStandERuote::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_accessori_stand_e_ruote');
  }
  function accessori_cappe() {
    return $this->belongsToMany(AccessoriCappe::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_accessori_cappe');
  }
  function altri_accessori() {
    return $this->belongsToMany(AltriAccessori::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_altri_accessori');
  }
  function accessori_raccomandati() {
    return $this->belongsToMany(AccessoriRaccomandati::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_accessori_raccomandati');
  }
}
