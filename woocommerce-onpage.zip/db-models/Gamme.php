<?php
namespace Op; 
class Gamme extends \OpLib\Term {
  public static function boot() {
    parent::boot();
    self::addGlobalScope('op', function($q) {
      $q->where('op_res', 728)->loaded();
    });
  }
  function settore() {
    return $this->belongsToMany(Settore::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_settore');
  }
  function versione() {
    return $this->belongsToMany(Versione::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_versione');
  }
}
