<?php
namespace Op; 
class Accessori extends \OpLib\Term {
  public static function boot() {
    parent::boot();
    self::addGlobalScope('op', function($q) {
      $q->where('op_res', 976)->loaded();
    });
  }
}
