<?php
namespace Op; 
class KeyFeatures extends \OpLib\Term {
  public static function boot() {
    parent::boot();
    self::addGlobalScope('op', function($q) {
      $q->where('op_res', 744)->loaded();
    });
  }
  function articoli() {
    return $this->belongsToMany(Forni::class, \OpLib\TermMeta::class, 'term_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_articoli');
  }
}
