<?php
namespace Op; 
class Forni extends \OpLib\Post {
  public static function boot() {
    parent::boot();
    self::addGlobalScope('op', function($q) {
      $q->where('op_res', 730)->loaded();
    });
  }
  function power_supply() {
    return $this->belongsToMany(PowerSupply::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_power_supply');
  }
  function accessori_spec_sheet() {
    return $this->belongsToMany(AccessoriSpecSheet::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_accessori_spec_sheet');
  }
  function standard_cooking_features() {
    return $this->belongsToMany(StandardCookingFeatures::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_standard_cooking_features');
  }
  function app_e_web_services1() {
    return $this->belongsToMany(AppEWebServices::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_app_e_web_services1');
  }
  function key_features() {
    return $this->belongsToMany(KeyFeatures::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_key_features');
  }
  function standard_technical_features() {
    return $this->belongsToMany(StandardTechnicalFeatures::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_standard_technical_features');
  }
  function connection_positions() {
    return $this->belongsToMany(ConnectionPositions::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_connection_positions');
  }
  function dettaglio_spec_sheet() {
    return $this->belongsToMany(DettaglioSpecSheet::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_dettaglio_spec_sheet');
  }
  function versione_teglie() {
    return $this->belongsToMany(VersioneTeglie::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_versione_teglie');
  }
  function variations() {
    return $this->belongsToMany(Forni::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_variations');
  }
  function articoli() {
    return $this->belongsToMany(Forni::class, \OpLib\PostMeta::class, 'post_id', 'meta_value', null, 'op_id')
    ->wherePivot('meta_key', 'op_articoli');
  }
}
