<?php
namespace OpLib;

if (!defined('OP_PLUGIN')) die(400);


class Model extends \WeDevs\ORM\Eloquent\Model {

}