<?php
namespace OpLib;

if (!defined('OP_PLUGIN')) die(400);

use WeDevs\ORM\Eloquent\Model;

class Post extends Model {
  use MetaFunctions;

  protected $table = OP_WP_PREFIX.'posts';
  protected $guarded = [];
  public $timestamps = false;
  public $is_post = true;
  protected $primaryKey = 'ID';
  protected static $meta_ref = 'post_id';
  protected static $meta_class = PostMeta::class;
  protected static $slug_field = 'post_name';

  public function scopeSlug($q, $slug) {
    $q->where('post_name', $slug);
  }

  public function icl_translation() {
    return $this->hasOne(IclTranslation::class, 'element_id', 'ID')->where('element_type', 'post_product');
  }
}
